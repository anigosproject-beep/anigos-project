import {defineConfig} from 'sanity'
import {structureTool} from 'sanity/structure'
import {visionTool} from '@sanity/vision'
import {media} from 'sanity-plugin-media'
import {languageFilter} from '@sanity/language-filter'

import {schemaTypes, SINGLETON_TYPES} from './sanity/schemaTypes'
import {structure} from './sanity/structure'
import {LANGUAGES} from './sanity/lib/locale'

/**
 * INI SATU-SATUNYA sanity.config.ts YANG BOLEH AKTIF.
 *
 * `schemaTypes` di sini sudah menggabungkan schema baru (18 halaman +
 * koleksi) DENGAN schema lama dari studio-anigos-project (newsroomArticle,
 * newsroomCategory, teamMember) lewat sanity/schemaTypes/legacy.ts.
 *
 * SEBELUM MENJALANKAN INI, LAKUKAN URUTAN INI — jangan dilompati:
 *
 *   1. Buka config Studio lama (studio-anigos-project/sanity.config.ts atau
 *      sanity.cli.ts) dan salin persis projectId + dataset dari sana ke
 *      .env.local proyek ini. Jangan menebak atau menulis ulang dari
 *      ingatan — project Sanity salah berarti tulisan konten masuk ke
 *      dataset yang salah tanpa ada tanda kesalahan sampai frontend
 *      di-fetch dan hasilnya kosong.
 *
 *   2. Buka sanity/schemaTypes/legacy.ts dan perbaiki path + bentuk import
 *      di sana sesuai isi asli studio-anigos-project/schemaTypes/. File itu
 *      berisi tebakan yang HARUS diverifikasi, bukan fakta.
 *
 *   3. Jalankan `npx sanity schema validate` dari root proyek ini. Kalau ada
 *      nama tipe yang bentrok antara schema baru dan lama (dua defineType
 *      dengan `name` yang sama tapi bentuk field beda), perbaiki di sini
 *      SEBELUM mencoba membuka Studio — bentrok nama tipe bisa membuat salah
 *      satu definisi menang secara diam-diam tanpa error yang jelas.
 *
 *   4. Setelah Studio ini terbukti bisa membuka semua dokumen lama (newsroom,
 *      team) DAN semua dokumen baru tanpa error, matikan/hapus config Studio
 *      lama supaya tidak ada dua Studio hidup berdampingan terhadap dataset
 *      yang sama. Jangan hapus lebih dulu — buktikan dulu yang baru bekerja.
 *
 *   5. Daftarkan origin Studio (domain dev dan production) di
 *      manage.sanity.io → API → CORS Origins dengan "Allow credentials"
 *      menyala, sebelum menguji di luar localhost.
 */

const singletons = new Set<string>(SINGLETON_TYPES)

export default defineConfig({
  name: 'petro-anigos',
  title: 'Petro Anigos',
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET ?? 'production',
  basePath: '/studio',

  plugins: [
    structureTool({structure}),

    /**
     * Tombol bahasa di atas form. Editor bisa menyembunyikan kolom English
     * saat menulis draft Indonesia, lalu menyalakannya untuk terjemahan.
     */
    languageFilter({
      supportedLanguages: LANGUAGES.map((l) => ({id: l.id, title: l.title})),
      defaultLanguages: ['id'],
      documentTypes: schemaTypes.filter((t) => t.type === 'document').map((t) => t.name),
      filterField: (enclosingType, member, selectedLanguageIds) =>
        !enclosingType.name.startsWith('locale') ||
        selectedLanguageIds.includes(member.name),
    }),

    /** Media library dengan tag dan pencarian — penting karena asset situs ini banyak. */
    media(),

    visionTool(),
  ],

  schema: {
    types: schemaTypes,

    /** Singleton tidak boleh dibuat lewat tombol "+" global. */
    templates: (prev) => prev.filter((t) => !singletons.has(t.schemaType)),
  },

  document: {
    /** Singleton tidak bisa dihapus, diduplikasi, atau diubah ID-nya. */
    actions: (prev, {schemaType}) =>
      singletons.has(schemaType)
        ? prev.filter(
            (action) =>
              !['delete', 'duplicate', 'unpublish'].includes(action.action ?? ''),
          )
        : prev,

    /** Tombol pratinjau ke halaman aslinya. */
    productionUrl: async (prev, {document}) => {
      const route = (document as {meta?: {route?: string}}).meta?.route
      if (!route) return prev
      const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'
      return `${base}/api/draft?slug=${encodeURIComponent(route)}`
    },
  },
})

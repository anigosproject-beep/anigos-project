# Rencana Penggabungan Studio — Petro Anigos

Dokumen ini khusus soal menggabungkan schema baru dengan
`studio-anigos-project/` yang sudah berjalan. Untuk penerapan skema secara
umum, lihat `PANDUAN-PENERAPAN.md`.

## Apa yang sudah saya kerjakan

- `sanity/schemaTypes/legacy.ts` — jembatan yang mengimpor `newsroomArticle`,
  `newsroomCategory`, `teamMember` dari `studio-anigos-project/schemaTypes/`
  dan mendaftarkannya ke registry gabungan.
- `sanity/schemaTypes/index.ts` — sekarang mengekspor schema baru + schema
  lama dalam satu array.
- `structure.ts` — menambah folder "Newsroom" (Artikel, Kategori Artikel) dan
  "Tim", memakai `S.documentTypeList()` generik yang tidak butuh tahu bentuk
  field internal dokumen lama.
- `sanity.config.ts` — dijadikan satu-satunya config, dengan checklist
  pre-flight tertulis langsung di komentar file-nya.
- `lib/page.ts` — `ROUTES` sekarang diturunkan dari `ROUTE_ENTRIES`, satu
  sumber untuk dropdown CTA (`shared.ts`) dan (nanti) skrip CI pengecek
  route drift. Sebelumnya ini dua daftar terpisah yang bisa diam-diam beda.
- Perbaikan kecil: `allowSvg` sekarang benar-benar memfilter tipe file;
  logo punya preset sendiri (bukan preset pattern); pattern dekoratif tidak
  lagi mewajibkan alt text (`decorative: true` men-skip field alt sesuai
  praktik aksesibilitas — gambar dekoratif murni memang seharusnya
  `aria-hidden`, bukan diberi alt kosong paksa); counter karakter sekarang
  memakai satuan yang sama dengan validator Sanity (`string.length`, bukan
  hitungan grapheme yang tadinya saya klaim salah); aturan video hero
  beranda saya longgarkan jadi "maksimal satu slide video di posisi
  manapun", bukan "slide pertama wajib video" — supaya tim konten bisa
  mengganti hero ke gambar tanpa perlu deploy kode.

## Apa yang TIDAK bisa saya kerjakan tanpa file aslimu

`sanity/schemaTypes/legacy.ts` isinya tebakan berlabel jelas. Dua hal yang
paling mungkin salah:

1. **Path import.** Saya menulis `../../studio-anigos-project/schemaTypes/...`
   — ini asumsi soal di mana folder `sanity/` hasil kerja saya akan kamu
   taruh relatif terhadap `studio-anigos-project/`. Kalau strukturnya beda,
   TypeScript langsung gagal resolve module, dan errornya jelas — bukan
   silent failure.
2. **Bentuk export.** Saya asumsikan named export
   (`export const newsroomArticle = ...`). Kalau sumbernya `export default`,
   import harus disesuaikan. Ini juga gagal jelas saat build, bukan diam-diam.

Keduanya bukan risiko "rusak tanpa ketahuan" — TypeScript akan menolak
compile kalau salah. Yang lebih berbahaya justru poin berikutnya, karena itu
tidak akan pernah error di compiler.

## Yang harus kamu putuskan: pola i18n newsroom/team

Ini keputusan yang tidak bisa saya buatkan otomatis karena saya belum melihat
field aslinya. Kemungkinan besar `newsroomArticle` dan `teamMember` memakai
field string biasa (bukan `{id, en}` seperti skema baru). Ada dua pilihan,
dan keduanya valid — bedanya di seberapa jauh kamu mau kerja sekarang:

### Opsi A — Biarkan monolingual (lebih cepat)

Artikel dan profil tim tetap bahasa Indonesia saja, tidak ikut pola
dwibahasa. Ini masuk akal kalau newsroom memang belum jadi prioritas
multibahasa. Yang perlu dilakukan: cukup dokumentasikan ini secara sadar di
`legacy.ts` (sudah ada tempatnya), supaya developer berikutnya tidak
bertanya-tanya kenapa dua bagian Studio punya pola berbeda.

### Opsi B — Konversi ke pola `{id, en}` (konsisten, lebih banyak kerja)

Ubah field `title`/`body`/dst di `newsroomArticle` dan `teamMember` memakai
`localeField`/`localeText` dari `lib/locale.ts`, sama seperti 18 halaman
lainnya. Konsekuensinya:

- Field lama yang isinya string harus dimigrasi jadi objek `{id: <string
  lama>, en: ''}` — perlu skrip migrasi data satu kali karena bentuk field
  berubah, meskipun dataset production untuk newsroom sendiri kemungkinan
  sudah tidak kosong (beda dari 18 halaman baru yang datasetnya kosong).
- Body artikel kemungkinan Portable Text, bukan `text` biasa —
  `localeField`/`localeText` saya tidak dirancang untuk Portable Text.
  Kalau field body memang Portable Text, perlu varian baru:
  `localePortableText` yang membungkus dua rich-text editor (ID/EN) alih-alih
  dua textarea. Saya belum membuat ini karena belum tahu apakah dibutuhkan.

**Rekomendasi saya:** Opsi A dulu. Jangan gabungkan migrasi data dengan
migrasi arsitektur Studio di waktu yang sama — dua risiko sekaligus lebih
sulit di-debug kalau ada yang salah. Konversi ke Opsi B bisa jadi pekerjaan
terpisah setelah Studio gabungan ini terbukti stabil.

## Checklist sebelum Studio gabungan ini dianggap siap

- [ ] `.env.local` berisi `projectId`/`dataset` yang disalin persis dari
      config Studio lama (bukan ditulis ulang dari ingatan)
- [ ] Path dan bentuk export di `legacy.ts` sudah diperbaiki sesuai file asli
- [ ] `npx sanity schema validate` lolos tanpa error nama tipe bentrok
- [ ] `npx tsc --noEmit` lolos
- [ ] Studio bisa dibuka di localhost, folder Newsroom dan Tim menampilkan
      dokumen yang sudah ada (bukan kosong)
- [ ] Satu dokumen newsroom lama dan satu dokumen 18-halaman baru sama-sama
      bisa dibuka dan disimpan tanpa error
- [ ] CORS origin (dev + production) sudah didaftarkan di manage.sanity.io
- [ ] Config Studio lama (`studio-anigos-project/sanity.config.ts`) sudah
      dinonaktifkan — setelah, bukan sebelum, poin di atas semua lolos
- [ ] Keputusan Opsi A vs B untuk i18n newsroom/team sudah diambil dan
      dituliskan sebagai komentar di `legacy.ts`

import {defineField, defineType} from 'sanity'
import type {FieldDefinition, FieldGroupDefinition} from 'sanity'

/**
 * Tab yang sama di setiap halaman, supaya editor selalu menemukan hal yang
 * sama di tempat yang sama.
 */
export const PAGE_GROUPS: FieldGroupDefinition[] = [
  {name: 'hero', title: 'Hero', default: true},
  {name: 'content', title: 'Isi halaman'},
  {name: 'closing', title: 'Penutup'},
  {name: 'seo', title: 'SEO'},
]

/**
 * Field dasar setiap halaman: identitas (route + breadcrumb) dan SEO.
 * `route` dikunci agar CMS tidak pernah mengubah URL yang dirender kode.
 */
export function pageBaseFields(route: string): FieldDefinition[] {
  return [
    defineField({
      name: 'meta',
      title: 'Identitas halaman',
      type: 'pageMeta',
      group: 'hero',
      initialValue: {route},
      validation: (rule) => rule.required(),
    } as never),
    defineField({
      name: 'seo',
      title: 'SEO & berbagi tautan',
      type: 'seo',
      group: 'seo',
    } as never),
  ]
}

type PageOptions = {
  name: string
  title: string
  route: string
  /** field spesifik halaman, sudah termasuk group-nya masing-masing */
  fields: FieldDefinition[]
  /** subtitle di daftar dokumen */
  subtitle?: string
}

/** Membuat satu dokumen singleton halaman. */
export function definePage(opts: PageOptions) {
  const {name, title, route, fields, subtitle} = opts

  return defineType({
    name,
    title,
    type: 'document',
    groups: PAGE_GROUPS,
    fields: [...pageBaseFields(route), ...fields],
    preview: {
      prepare: () => ({title, subtitle: subtitle ?? route}),
    },
  } as never)
}

/**
 * Satu-satunya daftar route halaman di seluruh Studio.
 *
 * PENTING: `cta` (schemaTypes/objects/shared.ts) dan `structure.ts` dulu
 * pernah menulis ulang daftar route ini secara manual masing-masing —
 * itu bug drift yang sudah diperbaiki. Sekarang keduanya membangun
 * pilihannya dari `ROUTE_ENTRIES` di bawah. Menambah halaman baru cukup
 * menambah satu baris di sini; dropdown CTA dan validasi lain ikut update
 * otomatis.
 *
 * Skrip CI yang membandingkan daftar ini dengan struktur folder `app/`
 * sebaiknya membaca `ROUTE_ENTRIES`, bukan `ROUTES`, supaya label untuk
 * pesan error juga tersedia.
 */
export const ROUTE_ENTRIES = [
  {key: 'home', path: '/', label: 'Beranda'},
  {key: 'jangkauan', path: '/jangkauan', label: 'Jangkauan'},
  {key: 'keberlanjutan', path: '/keberlanjutan', label: 'Keberlanjutan'},
  {
    key: 'energiBerkelanjutan',
    path: '/keberlanjutan/energi-berkelanjutan',
    label: 'Energi Berkelanjutan',
  },
  {
    key: 'kemitraanTataKelola',
    path: '/keberlanjutan/kemitraan-tata-kelola',
    label: 'Kemitraan & Tata Kelola',
  },
  {
    key: 'keselamatanOperasional',
    path: '/keberlanjutan/keselamatan-operasional',
    label: 'Keselamatan Operasional',
  },
  {key: 'kenaliProduk', path: '/produk/kenali-produk', label: 'Kenali Produk'},
  {key: 'armada', path: '/produk/armada', label: 'Armada'},
  {key: 'penawaran', path: '/produk/penawaran', label: 'Penawaran'},
  {key: 'ajukanPenawaran', path: '/produk/penawaran/ajukan', label: 'Ajukan Penawaran'},
  {key: 'profilPerusahaan', path: '/tentang-kami/profil-perusahaan', label: 'Profil Perusahaan'},
  {key: 'harapanCitaCita', path: '/tentang-kami/harapan-cita-cita', label: 'Harapan & Cita-Cita'},
  {key: 'kemitraan', path: '/tentang-kami/kemitraan', label: 'Kemitraan'},
  {key: 'legalitas', path: '/tentang-kami/legalitas', label: 'Legalitas'},
  {key: 'karir', path: '/tentang-kami/karir', label: 'Karir'},
  {key: 'lamaran', path: '/tentang-kami/karir/lamar', label: 'Form Lamaran'},
  {key: 'kebijakanData', path: '/kebijakan-data', label: 'Kebijakan Data'},
  {key: 'ketentuanCookies', path: '/ketentuan-cookies', label: 'Ketentuan Cookies'},
] as const

/** Bentuk map `{key: path}`. Dipakai kode lama yang mengharapkan objek datar. */
export const ROUTES = Object.fromEntries(
  ROUTE_ENTRIES.map((r) => [r.key, r.path]),
) as {[K in (typeof ROUTE_ENTRIES)[number]['key']]: string}

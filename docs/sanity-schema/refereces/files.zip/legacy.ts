/**
 * Jembatan ke schema Studio LAMA (`studio-anigos-project/`).
 *
 * ==================================================================
 * ASUMSI YANG BELUM DIVERIFIKASI — PERBAIKI FILE INI SETELAH KAMU
 * MEMBAGIKAN ISI ASLI studio-anigos-project/schemaTypes/
 * ==================================================================
 *
 * Saya belum pernah melihat isi folder itu. Path dan nama export di bawah
 * ini ditebak dari konvensi Sanity yang umum dan dari nama file yang kamu
 * sebutkan sebelumnya (studio-anigos-project/schemaTypes/newsroomArticle.ts,
 * teamMember.ts). Ada dua kemungkinan besar yang bisa salah:
 *
 *   1. Path relatif dari sini ke studio-anigos-project/ belum tentu benar
 *      — tergantung di mana folder sanity/ (hasil skema baru) ini akhirnya
 *      kamu taruh relatif terhadap studio-anigos-project/.
 *   2. Nama export belum tentu named export dengan nama yang sama persis
 *      seperti nama file. Sanity Studio sering pakai `export default`,
 *      kadang named export dengan nama beda dari nama file.
 *
 * CARA MEMPERBAIKI:
 *   Buka setiap file sumbernya, lihat baris paling bawah / paling atas
 *   yang berisi `export`, lalu samakan import di bawah ini persis.
 *
 *   Kalau exportnya `export default defineType({...})`:
 *     import newsroomArticle from '<path>/newsroomArticle'
 *
 *   Kalau exportnya `export const newsroomArticle = defineType({...})`:
 *     import {newsroomArticle} from '<path>/newsroomArticle'
 *
 * mediaLibrary SENGAJA tidak diimpor di sini. Rencana di PANDUAN-PENERAPAN.md
 * adalah menggantinya bertahap dengan plugin `sanity-plugin-media` yang
 * sudah dipasang di sanity.config.ts. Import ulang tipe ini HANYA jika kamu
 * belum siap memindahkan asset yang sudah ada ke plugin baru.
 */

// TODO verifikasi path — lihat catatan di atas
import {newsroomArticle} from '../../studio-anigos-project/schemaTypes/newsroomArticle'
import {newsroomCategory} from '../../studio-anigos-project/schemaTypes/newsroomCategory'
import {teamMember} from '../../studio-anigos-project/schemaTypes/teamMember'

export const legacySchemaTypes = [newsroomArticle, newsroomCategory, teamMember]

/**
 * Nama tipe dokumen lama, untuk didaftarkan di structure.ts tanpa perlu
 * tahu bentuk field internalnya — cukup nama tipenya harus cocok dengan
 * `name:` di masing-masing defineType() sumber.
 */
export const LEGACY_DOCUMENT_TYPES = {
  newsroomArticle: 'newsroomArticle',
  newsroomCategory: 'newsroomCategory',
  teamMember: 'teamMember',
} as const
